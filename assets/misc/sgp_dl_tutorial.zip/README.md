### SGP 2025 Graduate School
# Deep learning on meshes and point clouds
Ruben Wiersma

## Instructions
[Skip to instructions for Visual Studio Code](#alternative-in-visual-studio-code)

For this tutorial, you need Conda, a python environment management tool. You can download and install a minimal version, Miniconda, from here: https://www.anaconda.com/docs/getting-started/miniconda/install

Once you have conda installed, run the following command in your terminal:
```bash
conda create -n sgp_dl python=3.12 jupyter
```
This creates a Python environment called `sgp_dl` with Python 3.12 and Jupyter installed.

Now you're ready to open the tutorial notebook. Run the following code to get started:
```bash
cd [root_folder]
conda activate sgp_dl
jupyter notebook
```
This command starts the Jupyter server and opens the Jupyter interface in your browser. If you don't see it, check your terminal for instructions on where to go. It's often located at http://localhost:8889

Then click on `sgp_dl_tutorial.ipynb` in the Jupyter file browser and follow the instructions in the notebook.

### Alternative in Visual Studio Code
You can also run the notebook within Visual Studio Code. Simply open `sgp_dl_tutorial.ipynb` in Visual Studio Code, select the `sgp_dl` environment in the top-right corner ("Select Kernel" $\rightarrow$ "Python Environments") and go through the notebook step-by-step.